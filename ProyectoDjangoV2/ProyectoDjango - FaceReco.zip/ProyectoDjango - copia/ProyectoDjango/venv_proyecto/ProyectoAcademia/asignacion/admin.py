from django.contrib import admin
from .models import Asignacion, AsignacionCurso

admin.site.register([Asignacion, AsignacionCurso])
