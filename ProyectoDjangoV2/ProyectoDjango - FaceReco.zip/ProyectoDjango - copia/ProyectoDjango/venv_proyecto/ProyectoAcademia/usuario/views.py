from django.shortcuts import render
from .models import UsuarioAlumno, UsuarioProfesor

def usuario(request):

    usuario=UsuarioAlumno.objects.all()

    return render(request,"usuario/usuario.html", {"usuario":usuario})

